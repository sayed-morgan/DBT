function theRGB = simRGBfromSpectralFlux( theSpectralFlux, theRGBCurves);

theRGB = (theSpectralFlux * theRGBCurves);
