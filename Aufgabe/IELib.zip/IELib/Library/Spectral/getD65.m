function theD65 = getD65()
%Usage: theD65 = getD65();

D65 = load( 'D65.mat');
theD65 = D65.D65;
