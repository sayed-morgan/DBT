function theD50 = getD50()
%Usage: theD50 = getD50();

D50 = load( 'D50.mat');
theD50 = D50.D50;
