function theDensityImage = applyFilmLut( theScanImage, theFilmLut)
theDensityImage = applyRGBLut( theScanImage, theFilmLut);
end %applyFilmLut

