function theWeights = getDeltaEWeight( theXYZ, theXYZWhitePoint)
%Usage:		theWeights = getDeltaEWeight( theXYZ, theXYZWhitePoint);

theWeights = getWeightsXYZ( theXYZ, theXYZWhitePoint);

